package ge.airstring

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** Draws the string, detects plucks (hand landmarks + touch), sets pitch from string length. */
class StringOverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var synth: StringSynth? = null
    var snapToNotes = false
    var twoHandMode = false

    private var a: PointF? = null
    private var b: PointF? = null
    private var freq = 220f
    private val pluckers = ArrayList<Pair<String, PointF>>()
    private val prevSide = HashMap<String, Float>()

    private data class Vib(val t0: Long, val pos: Float, val amp: Float)
    private val vibs = ArrayList<Vib>()

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 28f; strokeCap = Paint.Cap.ROUND; color = Color.argb(50, 255, 213, 74)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 8f; strokeCap = Paint.Cap.ROUND; color = Color.rgb(255, 213, 74)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val tipDot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(230, 120, 220, 255) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 64f; isFakeBoldText = true; setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val hint = Paint(text).apply { textSize = 38f; isFakeBoldText = false }
    private val path = Path()
    private var hintText = "აჩვენე ხელი, გაშალე ცერი და საჩვენებელი"

    /** hands: per hand 21 landmarks as [x,y] normalized to the (rotated, mirrored) image. */
    fun onHands(hands: List<List<FloatArray>>, imgW: Int, imgH: Int) {
        // PreviewView default = FILL_CENTER: scale to cover, center-crop.
        val s = max(width / imgW.toFloat(), height / imgH.toFloat())
        val ox = (width - imgW * s) / 2f
        val oy = (height - imgH * s) / 2f
        fun px(h: List<FloatArray>, i: Int) = PointF(h[i][0] * imgW * s + ox, h[i][1] * imgH * s + oy)

        pluckers.clear()
        var na: PointF? = null
        var nb: PointF? = null
        if (twoHandMode && hands.size >= 2) {
            na = px(hands[0], 8); nb = px(hands[1], 8)
            hands.forEachIndexed { hi, h -> pluckers.add("h$hi-12" to px(h, 12)) }
        } else if (hands.isNotEmpty()) {
            val hold = hands.indices.maxBy { i ->
                val h = hands[i]; hypot(h[4][0] - h[8][0], h[4][1] - h[8][1])
            }
            na = px(hands[hold], 4); nb = px(hands[hold], 8)
            hands.forEachIndexed { hi, h ->
                val tips = if (hi == hold) intArrayOf(12, 16, 20) else intArrayOf(4, 8, 12, 16, 20)
                tips.forEach { k -> pluckers.add("h$hi-$k" to px(h, k)) }
            }
        }
        if (na != null && nb != null) {
            a = smooth(a, na); b = smooth(b, nb)
            hintText = "გადაატარე თითი სიმს"
            pluckers.forEach { (id, p) -> tryPluck(id, p, null) }
        } else {
            a = null; b = null
            hintText = if (twoHandMode) "აჩვენე ორივე ხელი" else "აჩვენე ხელი, გაშალე ცერი და საჩვენებელი"
        }
        invalidate()
    }

    private fun smooth(old: PointF?, n: PointF, k: Float = 0.45f) =
        if (old == null) n else PointF(old.x + (n.x - old.x) * k, old.y + (n.y - old.y) * k)

    private fun tryPluck(id: String, p: PointF, speed: Float?) {
        val pa = a ?: return
        val pb = b ?: return
        val dx = pb.x - pa.x; val dy = pb.y - pa.y
        val len = hypot(dx, dy)
        if (len < 60f) return
        val t = ((p.x - pa.x) * dx + (p.y - pa.y) * dy) / (len * len)
        val d = ((p.x - pa.x) * dy - (p.y - pa.y) * dx) / len
        val prev = prevSide.put(id, d) ?: return
        if (t < 0.04f || t > 0.96f) return
        if (sign(prev) != sign(d) && abs(prev - d) > 3f) {
            val vel = min(1f, (speed ?: abs(prev - d)) / 90f)
            synchronized(vibs) {
                vibs.add(Vib(SystemClock.uptimeMillis(), t, 14f + 40f * vel))
                if (vibs.size > 6) vibs.removeAt(0)
            }
            synth?.pluck(freq, vel, t)
            buzz()
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(12, 80)) else v.vibrate(12)
    }

    // ---- touch plucking ----
    private val lastTouch = HashMap<Int, Triple<Float, Float, Long>>()
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (a == null || b == null) {
            // no hands: give a fixed demo string so touch still plays
            a = PointF(width * 0.15f, height * 0.5f); b = PointF(width * 0.85f, height * 0.5f)
        }
        for (i in 0 until e.pointerCount) {
            val pid = e.getPointerId(i)
            val id = "t$pid"
            val p = PointF(e.getX(i), e.getY(i))
            val now = SystemClock.uptimeMillis()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    prevSide.remove(id); lastTouch[pid] = Triple(p.x, p.y, now); tryPluck(id, p, null)
                }
                MotionEvent.ACTION_MOVE -> {
                    val q = lastTouch[pid]
                    val sp = if (q != null) hypot(p.x - q.first, p.y - q.second) / max(1L, now - q.third) * 50f else 0f
                    lastTouch[pid] = Triple(p.x, p.y, now)
                    tryPluck(id, p, sp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                    prevSide.remove(id); lastTouch.remove(pid)
                }
            }
        }
        invalidate()
        return true
    }

    // ---- pitch ----
    private val names = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val penta = intArrayOf(0, 2, 4, 7, 9)

    private fun lengthToFreq(len: Float): Float {
        val diag = hypot(width.toFloat(), height.toFloat())
        val n = max(0.04f, len / diag)
        var f = (82.4f * (0.75f / n)).coerceIn(65f, 1100f)
        if (snapToNotes) {
            var m = (12 * log2(f / 440f) + 69).roundToInt()
            while (((m % 12) + 12) % 12 !in penta) m--
            f = 440f * 2f.pow((m - 69) / 12f)
        }
        return f
    }

    private fun noteName(f: Float): String {
        val m = (12 * log2(f / 440f) + 69).roundToInt()
        return names[((m % 12) + 12) % 12] + (m / 12 - 1)
    }

    // ---- drawing ----
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val pa = a; val pb = b
        val now = SystemClock.uptimeMillis()
        if (pa != null && pb != null) {
            val dx = pb.x - pa.x; val dy = pb.y - pa.y
            val len = hypot(dx, dy)
            freq = lengthToFreq(len)
            val nx = -dy / max(1f, len); val ny = dx / max(1f, len)
            val active = synchronized(vibs) { vibs.removeAll { now - it.t0 > 2500 }; vibs.toList() }
            path.reset()
            val seg = 64
            for (i in 0..seg) {
                val s = i / seg.toFloat()
                var off = 0f
                for (v in active) {
                    val tt = (now - v.t0) / 1000f
                    val env = exp(-tt * 2.2f)
                    for (n in 1..5) {
                        val an = sin(n * PI.toFloat() * v.pos) / (n * n)
                        off += v.amp * an * sin(n * PI.toFloat() * s) * cos(2 * PI.toFloat() * n * 9f * tt) * env
                    }
                }
                val x = pa.x + dx * s + nx * off
                val y = pa.y + dy * s + ny * off
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            c.drawPath(path, glow)
            c.drawPath(path, line)
            c.drawCircle(pa.x, pa.y, 22f, dot)
            c.drawCircle(pb.x, pb.y, 22f, dot)
            c.drawText("${noteName(freq)} · ${freq.roundToInt()} Hz", 40f, 120f, text)
            if (active.isNotEmpty()) postInvalidateOnAnimation()
        }
        pluckers.forEach { (_, p) -> c.drawCircle(p.x, p.y, 14f, tipDot) }
        c.drawText(hintText, 40f, 180f, hint)
    }
}
