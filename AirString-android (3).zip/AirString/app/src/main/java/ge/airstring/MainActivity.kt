package ge.airstring

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: StringOverlayView
    private lateinit var cameraExecutor: ExecutorService
    private var landmarker: HandLandmarker? = null
    private val synth = StringSynth()

    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera()
        else Toast.makeText(this, "კამერის გარეშე ეკრანზე შეეხე სიმს", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.preview)
        overlay = findViewById(R.id.overlay)
        overlay.synth = synth
        cameraExecutor = Executors.newSingleThreadExecutor()
        synth.start()

        findViewById<Button>(R.id.btnSnap).setOnClickListener {
            overlay.snapToNotes = !overlay.snapToNotes
            (it as Button).text = if (overlay.snapToNotes) "ნოტები: ჩართ." else "ნოტები: გამ."
        }
        findViewById<Button>(R.id.btnNew).setOnClickListener { overlay.startPlacing() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { overlay.clearStrings() }

        setupLandmarker()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else askCamera.launch(Manifest.permission.CAMERA)
    }

    private fun setupLandmarker() {
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, image ->
                val hands = result.landmarks().map { hand -> hand.map { floatArrayOf(it.x(), it.y()) } }
                overlay.post { overlay.onHands(hands, image.width, image.height) }
            }
            .setErrorListener { e -> e.printStackTrace() }
            .build()
        landmarker = HandLandmarker.createFromOptions(this, options)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(cameraExecutor) { proxy -> analyze(proxy) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        if (lm == null) { proxy.close(); return }
        val raw = proxy.toBitmap()
        // Rotate upright and mirror (front camera), so landmarks match what the user sees.
        val m = Matrix().apply {
            postRotate(proxy.imageInfo.rotationDegrees.toFloat())
            postScale(-1f, 1f)
        }
        val frame = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        val ts = proxy.imageInfo.timestamp / 1_000_000
        proxy.close()
        lm.detectAsync(BitmapImageBuilder(frame).build(), ts)
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        landmarker?.close()
        synth.stop()
    }
}
