package ge.airstring

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Plucked-string synth (Karplus–Strong), mixes several ringing strings. */
class StringSynth(private val sampleRate: Int = 44100) {

    private class Voice(freq: Float, amp: Float, pos: Float, sr: Int) {
        val ring: FloatArray
        var idx = 0
        var samplesLeft = (sr * 2.5f).toInt()
        val decay = 0.996f - min(0.006f, freq / 200000f)

        init {
            val n = max(2, (sr / freq).roundToInt())
            ring = FloatArray(n) { (Random.nextFloat() * 2f - 1f) * amp }
            val k = max(1, (n * pos.coerceIn(0.05f, 0.5f)).roundToInt())
            for (i in n - 1 downTo k) ring[i] -= ring[i - k]
        }

        fun next(): Float {
            val n = ring.size
            val a = ring[idx]
            val b = ring[(idx + 1) % n]
            ring[idx] = decay * 0.5f * (a + b)
            idx = (idx + 1) % n
            samplesLeft--
            return a
        }
    }

    private val voices = ArrayList<Voice>()
    @Volatile private var running = false
    private var thread: Thread? = null

    fun pluck(freq: Float, velocity: Float, position: Float) {
        val v = Voice(freq, 0.3f + 0.6f * velocity.coerceIn(0f, 1f), position, sampleRate)
        synchronized(voices) {
            voices.add(v)
            if (voices.size > 6) voices.removeAt(0)
        }
    }

    fun start() {
        if (running) return
        running = true
        thread = Thread {
            val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(minBuf, 1024 * 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            val out = ShortArray(256)
            while (running) {
                synchronized(voices) {
                    for (i in out.indices) {
                        var s = 0f
                        for (v in voices) s += v.next()
                        out[i] = (s.coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
                    }
                    voices.removeAll { it.samplesLeft <= 0 }
                }
                track.write(out, 0, out.size)
            }
            track.stop(); track.release()
        }.apply { priority = Thread.MAX_PRIORITY; start() }
    }

    fun stop() { running = false; thread?.join(300) }
}
