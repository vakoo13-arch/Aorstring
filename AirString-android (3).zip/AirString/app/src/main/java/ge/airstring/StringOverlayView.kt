package ge.airstring

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/**
 * One-hand flow:
 *  1) PLACING: a dashed string follows thumb–index tips. Hold the hand still ~1 s -> the string is "hung" in the air.
 *  2) PLAYING: hung strings stay fixed on screen; any fingertip (or a finger on the screen) crossing a string plucks it.
 *  "+ სიმი" hangs another string, "გასუფთავება" removes all.
 */
class StringOverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var synth: StringSynth? = null
    var snapToNotes = false

    private data class Vib(val t0: Long, val pos: Float, val amp: Float)
    private class HungString(val a: PointF, val b: PointF, val freq: Float) {
        val vibs = ArrayList<Vib>()
    }

    private val strings = ArrayList<HungString>()
    private var placing = true
    private var liveA: PointF? = null
    private var liveB: PointF? = null
    private var anchorA: PointF? = null
    private var anchorB: PointF? = null
    private var stillSince = 0L
    private val tips = ArrayList<Pair<String, PointF>>()
    private val prevSide = HashMap<String, Float>()
    private var hintText = "აჩვენე ხელი, გაშალე ცერი და საჩვენებელი"
    private var noteText = "—"

    private companion object {
        const val HOLD_MS = 1100L
        const val STILL_PX = 22f
        const val MIN_LEN = 110f
        const val MAX_STRINGS = 6
    }

    fun startPlacing() { placing = true; liveA = null; liveB = null; anchorA = null; invalidate() }
    fun clearStrings() { strings.clear(); prevSide.clear(); startPlacing() }

    // ---------------- hands ----------------
    /** hands: per hand 21 landmarks as [x,y], normalized to the rotated+mirrored camera image. */
    fun onHands(hands: List<List<FloatArray>>, imgW: Int, imgH: Int) {
        val s = max(width / imgW.toFloat(), height / imgH.toFloat())
        val ox = (width - imgW * s) / 2f
        val oy = (height - imgH * s) / 2f
        fun px(h: List<FloatArray>, i: Int) = PointF(h[i][0] * imgW * s + ox, h[i][1] * imgH * s + oy)

        tips.clear()
        if (placing) {
            if (hands.isEmpty()) {
                liveA = null; liveB = null; anchorA = null
                hintText = "აჩვენე ხელი, გაშალე ცერი და საჩვენებელი"
            } else {
                val hold = hands.indices.maxBy { i -> val h = hands[i]; hypot(h[4][0] - h[8][0], h[4][1] - h[8][1]) }
                val a = smooth(liveA, px(hands[hold], 4))
                val b = smooth(liveB, px(hands[hold], 8))
                liveA = a; liveB = b
                val now = SystemClock.uptimeMillis()
                if (dist(a, b) < MIN_LEN) {
                    anchorA = null
                    hintText = "ცერი და საჩვენებელი უფრო გაშალე"
                } else {
                    val aa = anchorA; val ab = anchorB
                    if (aa == null || ab == null || dist(a, aa) > STILL_PX || dist(b, ab) > STILL_PX) {
                        anchorA = PointF(a.x, a.y); anchorB = PointF(b.x, b.y); stillSince = now
                    }
                    hintText = "მოარგე და გააჩერე ხელი — დაიკიდება"
                    if (now - stillSince > HOLD_MS) hang(a, b)
                }
            }
        } else {
            hands.forEachIndexed { hi, h -> intArrayOf(4, 8, 12, 16, 20).forEach { k -> tips.add("h$hi-$k" to px(h, k)) } }
            hintText = if (hands.isEmpty()) "აჩვენე ხელი და დაუკარი" else "თითი გადაატარე სიმს"
            tips.forEach { (id, p) -> pluckAll(id, p, null) }
        }
        invalidate()
    }

    private fun hang(a: PointF, b: PointF) {
        val hs = HungString(PointF(a.x, a.y), PointF(b.x, b.y), lengthToFreq(dist(a, b)))
        hs.vibs.add(Vib(SystemClock.uptimeMillis(), 0.5f, 10f))
        strings.add(hs)
        if (strings.size > MAX_STRINGS) strings.removeAt(0)
        prevSide.clear()
        placing = false; liveA = null; liveB = null; anchorA = null
        buzz(30)
    }

    private fun dist(p: PointF, q: PointF) = hypot(p.x - q.x, p.y - q.y)
    private fun smooth(old: PointF?, n: PointF, k: Float = 0.4f) =
        if (old == null) n else PointF(old.x + (n.x - old.x) * k, old.y + (n.y - old.y) * k)

    // ---------------- plucking ----------------
    private fun pluckAll(id: String, p: PointF, speed: Float?) {
        for (i in strings.indices) tryPluck(i, id, p, speed)
    }

    private fun tryPluck(si: Int, id: String, p: PointF, speed: Float?) {
        val st = strings[si]
        val dx = st.b.x - st.a.x; val dy = st.b.y - st.a.y
        val len = max(1f, hypot(dx, dy))
        val t = ((p.x - st.a.x) * dx + (p.y - st.a.y) * dy) / (len * len)
        val d = ((p.x - st.a.x) * dy - (p.y - st.a.y) * dx) / len
        val prev = prevSide.put("$si:$id", d) ?: return
        if (t < 0.03f || t > 0.97f) return
        if (sign(prev) != sign(d) && abs(prev - d) > 3f) {
            val vel = min(1f, (speed ?: abs(prev - d)) / 90f)
            st.vibs.add(Vib(SystemClock.uptimeMillis(), t, 14f + 40f * vel))
            if (st.vibs.size > 5) st.vibs.removeAt(0)
            synth?.pluck(st.freq, vel, t)
            noteText = "${noteName(st.freq)} · ${st.freq.roundToInt()} Hz"
            buzz(12)
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz(ms: Long) {
        val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, 80)) else v.vibrate(ms)
    }

    // ---------------- touch ----------------
    private val lastTouch = HashMap<Int, Triple<Float, Float, Long>>()

    private fun clearTouch(pid: Int) {
        prevSide.keys.removeAll { it.endsWith(":t$pid") }
        lastTouch.remove(pid)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (strings.isEmpty() && e.actionMasked == MotionEvent.ACTION_DOWN) {
            // no strings yet: hang a default one so the screen is playable without the camera
            strings.add(HungString(PointF(width * 0.15f, height * 0.5f), PointF(width * 0.85f, height * 0.5f), lengthToFreq(width * 0.7f)))
            placing = false
        }
        val now = SystemClock.uptimeMillis()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; val pid = e.getPointerId(i)
                clearTouch(pid)
                lastTouch[pid] = Triple(e.getX(i), e.getY(i), now)
                pluckAll("t$pid", PointF(e.getX(i), e.getY(i)), null)
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val pid = e.getPointerId(i)
                val p = PointF(e.getX(i), e.getY(i))
                val q = lastTouch[pid]
                val sp = if (q != null) hypot(p.x - q.first, p.y - q.second) / max(1L, now - q.third) * 50f else 0f
                lastTouch[pid] = Triple(p.x, p.y, now)
                pluckAll("t$pid", p, sp)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> clearTouch(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> { prevSide.keys.removeAll { it.contains(":t") }; lastTouch.clear() }
        }
        invalidate()
        return true
    }

    // ---------------- pitch ----------------
    private val names = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val penta = intArrayOf(0, 2, 4, 7, 9)

    private fun lengthToFreq(len: Float): Float {
        val n = max(0.04f, len / hypot(width.toFloat(), height.toFloat()))
        var f = (82.4f * (0.75f / n)).coerceIn(65f, 1100f)
        if (snapToNotes) {
            var m = (12 * log2(f / 440f) + 69).roundToInt()
            while (((m % 12) + 12) % 12 !in penta) m--
            f = 440f * 2f.pow((m - 69) / 12f)
        }
        return f
    }

    private fun noteName(f: Float): String {
        val m = (12 * log2(f / 440f) + 69).roundToInt()
        return names[((m % 12) + 12) % 12] + (m / 12 - 1)
    }

    // ---------------- drawing ----------------
    private val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 8f; strokeCap = Paint.Cap.ROUND; color = Color.rgb(255, 213, 74)
    }
    private val goldGlow = Paint(gold).apply { strokeWidth = 28f; color = Color.argb(50, 255, 213, 74) }
    private val blue = Paint(gold).apply { color = Color.rgb(155, 231, 255); pathEffect = DashPathEffect(floatArrayOf(28f, 20f), 0f) }
    private val ring = Paint(gold).apply { color = Color.rgb(155, 231, 255); strokeWidth = 12f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val tipDot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(230, 120, 220, 255) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 64f; isFakeBoldText = true; setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val hint = Paint(text).apply { textSize = 38f; isFakeBoldText = false }
    private val path = Path()
    private val arcBox = RectF()

    private fun buildPath(a: PointF, b: PointF, vibs: List<Vib>, now: Long) {
        val dx = b.x - a.x; val dy = b.y - a.y
        val len = max(1f, hypot(dx, dy))
        val nx = -dy / len; val ny = dx / len
        path.reset()
        for (i in 0..64) {
            val s = i / 64f
            var off = 0f
            for (v in vibs) {
                val tt = (now - v.t0) / 1000f
                val env = exp(-tt * 2.2f)
                for (n in 1..5) {
                    off += v.amp * sin(n * PI.toFloat() * v.pos) / (n * n) *
                        sin(n * PI.toFloat() * s) * cos(2 * PI.toFloat() * n * 9f * tt) * env
                }
            }
            val x = a.x + dx * s + nx * off
            val y = a.y + dy * s + ny * off
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = SystemClock.uptimeMillis()
        var animating = false
        for (st in strings) {
            st.vibs.removeAll { now - it.t0 > 2500 }
            if (st.vibs.isNotEmpty()) animating = true
            buildPath(st.a, st.b, st.vibs, now)
            c.drawPath(path, goldGlow); c.drawPath(path, gold)
            c.drawCircle(st.a.x, st.a.y, 18f, dot); c.drawCircle(st.b.x, st.b.y, 18f, dot)
        }
        val a = liveA; val b = liveB
        if (placing && a != null && b != null) {
            buildPath(a, b, emptyList(), now)
            c.drawPath(path, blue)
            c.drawCircle(a.x, a.y, 18f, dot); c.drawCircle(b.x, b.y, 18f, dot)
            val f = lengthToFreq(dist(a, b))
            noteText = "${noteName(f)} · ${f.roundToInt()} Hz"
            if (anchorA != null) {
                val pr = min(1f, (now - stillSince) / HOLD_MS.toFloat())
                val mx = (a.x + b.x) / 2f; val my = (a.y + b.y) / 2f
                arcBox.set(mx - 44f, my - 44f, mx + 44f, my + 44f)
                c.drawArc(arcBox, -90f, 360f * pr, false, ring)
            }
        }
        tips.forEach { (_, p) -> c.drawCircle(p.x, p.y, 14f, tipDot) }
        c.drawText(noteText, 40f, 120f, text)
        c.drawText(hintText, 40f, 180f, hint)
        if (animating) postInvalidateOnAnimation()
    }
}
